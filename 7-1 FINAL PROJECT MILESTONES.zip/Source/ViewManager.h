#pragma once

#include <iostream>
#include <GL/glew.h>
#include <GLFW/glfw3.h>

#include "ShaderManager.h"
#include "camera.h"

class ViewManager
{
public:
    ViewManager(ShaderManager* pShaderManager);
    ~ViewManager();

    GLFWwindow* CreateDisplayWindow(const char* windowTitle);
    void PrepareSceneView();

private:
    void ProcessKeyboardEvents();

    static void Mouse_Position_Callback(GLFWwindow* window, double xpos, double ypos);
    static void Mouse_Scroll_Callback(GLFWwindow* window, double xoffset, double yoffset);

private:
    ShaderManager* m_pShaderManager;
    GLFWwindow* m_pWindow;
};
