﻿/////////////////////////////////////////////////////////////////////////////////
//
// SceneManager.cpp
// ============
// Manage loading, materials and rendering of 3D scene objects
//
/////////////////////////////////////////////////////////////////////////////////

#include <cstddef>   // FIX: needed before GLEW gets pulled in through headers
#include <cmath>     // ADDED: sin/cos for the ring detail around the pencil holder

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// ADDED: for Q/E input (vertical movement)
#include <GLFW/glfw3.h>   // ADDED

// ADDED: global world offset controlled by Q/E (no header changes needed)
static glm::vec3 s_worldOffset(0.0f, 0.0f, 0.0f);   // ADDED
static double s_lastInputTime = 0.0;                // ADDED

// Shader uniform names
namespace
{
    const char* g_ModelName = "model";
    const char* g_ColorValueName = "objectColor";
    const char* g_TextureValueName = "objectTexture";
    const char* g_UseTextureName = "bUseTexture";
    const char* g_UseLightingName = "bUseLighting";
}

//==============================================================
// Constructor / Destructor
//==============================================================
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
    m_pShaderManager = pShaderManager;
    m_basicMeshes = new ShapeMeshes();
    m_loadedTextures = 0;
}

SceneManager::~SceneManager()
{
    m_pShaderManager = NULL;
    delete m_basicMeshes;
    m_basicMeshes = NULL;
}

//==============================================================
// Texture loading and management
//==============================================================
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
    int width = 0, height = 0, colorChannels = 0;
    GLuint textureID = 0;

    // Flip image vertically so it matches OpenGL UV coordinates
    stbi_set_flip_vertically_on_load(true);
    unsigned char* image = stbi_load(filename, &width, &height, &colorChannels, 0);

    if (!image)
        return false;

    glGenTextures(1, &textureID);
    glBindTexture(GL_TEXTURE_2D, textureID);

    // Texture wrapping and filtering
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    if (colorChannels == 3)
    {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8,
            width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
    }
    else if (colorChannels == 4)
    {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8,
            width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
    }
    else
    {
        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0);
        return false;
    }

    glGenerateMipmap(GL_TEXTURE_2D);

    stbi_image_free(image);
    glBindTexture(GL_TEXTURE_2D, 0);

    m_textureIDs[m_loadedTextures].ID = textureID;
    m_textureIDs[m_loadedTextures].tag = tag;
    m_loadedTextures++;

    return true;
}

void SceneManager::BindGLTextures()
{
    // Bind all loaded textures to consecutive texture units
    for (int i = 0; i < m_loadedTextures; i++)
    {
        glActiveTexture(GL_TEXTURE0 + i);
        glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
    }
}

void SceneManager::DestroyGLTextures()
{
    // Delete all OpenGL textures
    for (int i = 0; i < m_loadedTextures; i++)
    {
        glDeleteTextures(1, &m_textureIDs[i].ID);
    }
    m_loadedTextures = 0;
}

//==============================================================
// Helper look-ups
//==============================================================
int SceneManager::FindTextureID(std::string tag)
{
    for (int i = 0; i < m_loadedTextures; i++)
    {
        if (m_textureIDs[i].tag == tag)
            return m_textureIDs[i].ID;
    }
    return -1;
}

int SceneManager::FindTextureSlot(std::string tag)
{
    for (int i = 0; i < m_loadedTextures; i++)
    {
        if (m_textureIDs[i].tag == tag)
            return i;
    }
    return -1;
}

bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
    for (int i = 0; i < static_cast<int>(m_objectMaterials.size()); i++)
    {
        if (m_objectMaterials[i].tag == tag)
        {
            material = m_objectMaterials[i];
            return true;
        }
    }
    return false;
}

//==============================================================
// Transformations and shader helpers
//==============================================================
void SceneManager::SetTransformations(
    glm::vec3 scaleXYZ,
    float XrotationDegrees,
    float YrotationDegrees,
    float ZrotationDegrees,
    glm::vec3 positionXYZ)
{
    // Keep Q/E movement exactly the same (global vertical offset)
    positionXYZ += s_worldOffset;

    glm::mat4 scale = glm::scale(scaleXYZ);
    glm::mat4 rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1, 0, 0));
    glm::mat4 rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0, 1, 0));
    glm::mat4 rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0, 0, 1));
    glm::mat4 translation = glm::translate(positionXYZ);

    glm::mat4 modelView = translation * rotationX * rotationY * rotationZ * scale;

    if (m_pShaderManager)
        m_pShaderManager->setMat4Value(g_ModelName, modelView);
}

void SceneManager::SetShaderColor(float r, float g, float b, float a)
{
    if (m_pShaderManager)
    {
        m_pShaderManager->setIntValue(g_UseTextureName, false);
        m_pShaderManager->setVec4Value(g_ColorValueName, glm::vec4(r, g, b, a));
    }
}

void SceneManager::SetShaderTexture(std::string textureTag)
{
    if (!m_pShaderManager)
        return;

    int slot = FindTextureSlot(textureTag);
    if (slot >= 0)
    {
        m_pShaderManager->setIntValue(g_UseTextureName, true);
        m_pShaderManager->setSampler2DValue(g_TextureValueName, slot);
    }
    else
    {
        m_pShaderManager->setIntValue(g_UseTextureName, false);
    }
}

void SceneManager::SetTextureUVScale(float u, float v)
{
    if (m_pShaderManager)
        m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
}

void SceneManager::SetShaderMaterial(std::string materialTag)
{
    if (!m_pShaderManager)
        return;

    OBJECT_MATERIAL mat;
    if (FindMaterial(materialTag, mat))
    {
        m_pShaderManager->setVec3Value("material.ambientColor", mat.ambientColor);
        m_pShaderManager->setFloatValue("material.ambientStrength", mat.ambientStrength);
        m_pShaderManager->setVec3Value("material.diffuseColor", mat.diffuseColor);
        m_pShaderManager->setVec3Value("material.specularColor", mat.specularColor);
        m_pShaderManager->setFloatValue("material.shininess", mat.shininess);
    }
}

//==============================================================
// Prepare Scene (textures + materials)
//==============================================================
void SceneManager::PrepareScene()
{
    // Load meshes
    m_basicMeshes->LoadPlaneMesh();
    m_basicMeshes->LoadBoxMesh();
    m_basicMeshes->LoadTaperedCylinderMesh();

    // Load textures
    CreateGLTexture("../../Utilities/textures/circular-brushed-gold-texture.jpg", "desk");
    CreateGLTexture("../../Utilities/textures/knife_handle.jpg", "cover");
    CreateGLTexture("../../Utilities/textures/drywall.jpg", "pages");
    CreateGLTexture("../../Utilities/textures/stainless_end.jpg", "metal");
    CreateGLTexture("../../Utilities/textures/cheddar.jpg", "penCheddar");
    CreateGLTexture("../../Utilities/textures/stainless.jpg", "stainless");

    // This is the texture you wanted on the pencil holder
    CreateGLTexture("../../Utilities/textures/backdrop.jpg", "backdrop");

    BindGLTextures();

    // Define materials
    m_objectMaterials.clear();

    // Desk material
    {
        OBJECT_MATERIAL m;
        m.tag = "desk";
        m.ambientColor = glm::vec3(0.6f, 0.5f, 0.2f);
        m.ambientStrength = 0.45f;
        m.diffuseColor = glm::vec3(0.9f, 0.8f, 0.4f);
        m.specularColor = glm::vec3(1.0f);
        m.shininess = 96.0f;
        m_objectMaterials.push_back(m);
    }

    // Notebook cover
    {
        OBJECT_MATERIAL m;
        m.tag = "cover";
        m.ambientColor = glm::vec3(0.25f, 0.12f, 0.06f);
        m.ambientStrength = 0.45f;
        m.diffuseColor = glm::vec3(0.55f, 0.32f, 0.18f);
        m.specularColor = glm::vec3(0.25f);
        m.shininess = 16.0f;
        m_objectMaterials.push_back(m);
    }

    // Pages
    {
        OBJECT_MATERIAL m;
        m.tag = "pages";
        m.ambientColor = glm::vec3(0.9f);
        m.ambientStrength = 0.60f;
        m.diffuseColor = glm::vec3(1.0f);
        m.specularColor = glm::vec3(0.35f);
        m.shininess = 24.0f;
        m_objectMaterials.push_back(m);
    }

    // Metal (cup, pencil holder, pen metal)
    {
        OBJECT_MATERIAL m;
        m.tag = "penMetal";
        m.ambientColor = glm::vec3(0.4f);
        m.ambientStrength = 0.55f;
        m.diffuseColor = glm::vec3(0.85f);
        m.specularColor = glm::vec3(1.0f);
        m.shininess = 80.0f;
        m_objectMaterials.push_back(m);
    }

    // Cheddar pen body
    {
        OBJECT_MATERIAL m;
        m.tag = "penCheddar";
        m.ambientColor = glm::vec3(1.0f, 0.9f, 0.5f);
        m.ambientStrength = 0.60f;
        m.diffuseColor = glm::vec3(1.0f, 0.9f, 0.6f);
        m.specularColor = glm::vec3(0.6f);
        m.shininess = 40.0f;
        m_objectMaterials.push_back(m);
    }

    // Glass lenses
    {
        OBJECT_MATERIAL m;
        m.tag = "glassLens";
        m.ambientColor = glm::vec3(0.7f, 0.8f, 0.9f);
        m.ambientStrength = 0.45f;
        m.diffuseColor = glm::vec3(0.8f, 0.9f, 1.0f);
        m.specularColor = glm::vec3(0.9f);
        m.shininess = 32.0f;
        m_objectMaterials.push_back(m);
    }

    // Pencil wood
    {
        OBJECT_MATERIAL m;
        m.tag = "pencilWood";
        m.ambientColor = glm::vec3(0.8f, 0.6f, 0.2f);
        m.ambientStrength = 0.55f;
        m.diffuseColor = glm::vec3(0.9f, 0.7f, 0.25f);
        m.specularColor = glm::vec3(0.4f);
        m.shininess = 24.0f;
        m_objectMaterials.push_back(m);
    }

    // Pencil lead
    {
        OBJECT_MATERIAL m;
        m.tag = "pencilLead";
        m.ambientColor = glm::vec3(0.1f, 0.1f, 0.1f);
        m.ambientStrength = 0.6f;
        m.diffuseColor = glm::vec3(0.2f, 0.2f, 0.2f);
        m.specularColor = glm::vec3(0.5f);
        m.shininess = 32.0f;
        m_objectMaterials.push_back(m);
    }
}

//==============================================================
// Render Scene
//==============================================================
void SceneManager::RenderScene()
{
    // Q/E vertical movement (do not touch anything else)
    GLFWwindow* window = glfwGetCurrentContext();
    if (window)
    {
        double now = glfwGetTime();
        double dt = now - s_lastInputTime;
        if (s_lastInputTime == 0.0) dt = 0.016;
        s_lastInputTime = now;

        const float moveSpeed = 2.5f;

        if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
            s_worldOffset.y += (float)(moveSpeed * dt);

        if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
            s_worldOffset.y -= (float)(moveSpeed * dt);
    }

    // --- Lighting setup (2 lights, one is colored, includes a point light) ---
    // I’m setting this once per frame so every object gets the same light rig.
    // The shader still does the actual Phong math (ambient/diffuse/specular) using the material values.
    if (m_pShaderManager)
    {
        m_pShaderManager->setIntValue(g_UseLightingName, true);

        glm::vec3 pointPos = glm::vec3(0.0f, 10.0f, 6.0f);
        glm::vec3 pointAmbient = glm::vec3(0.20f, 0.20f, 0.20f);
        glm::vec3 pointDiffuse = glm::vec3(0.90f, 0.90f, 0.90f);
        glm::vec3 pointSpecular = glm::vec3(1.00f, 1.00f, 1.00f);

        m_pShaderManager->setVec3Value("pointLight.position", pointPos);
        m_pShaderManager->setVec3Value("pointLight.ambient", pointAmbient);
        m_pShaderManager->setVec3Value("pointLight.diffuse", pointDiffuse);
        m_pShaderManager->setVec3Value("pointLight.specular", pointSpecular);

        glm::vec3 dirDirection = glm::vec3(-0.35f, -1.0f, -0.25f);
        glm::vec3 dirAmbient = glm::vec3(0.10f, 0.12f, 0.18f);
        glm::vec3 dirDiffuse = glm::vec3(0.25f, 0.30f, 0.55f);
        glm::vec3 dirSpecular = glm::vec3(0.35f, 0.35f, 0.55f);

        m_pShaderManager->setVec3Value("dirLight.direction", dirDirection);
        m_pShaderManager->setVec3Value("dirLight.ambient", dirAmbient);
        m_pShaderManager->setVec3Value("dirLight.diffuse", dirDiffuse);
        m_pShaderManager->setVec3Value("dirLight.specular", dirSpecular);

        m_pShaderManager->setVec3Value("lightPos", pointPos);
        m_pShaderManager->setVec3Value("lightColor", pointDiffuse);

        m_pShaderManager->setVec3Value("fillLightPos", glm::vec3(8.0f, 7.0f, -6.0f));
        m_pShaderManager->setVec3Value("fillLightColor", dirDiffuse);
    }

    glm::vec3 scaleXYZ;
    glm::vec3 pos;
    float Xrot, Yrot, Zrot;

    //----------------------------------------------------------
    // Desk plane
    //----------------------------------------------------------
    scaleXYZ = glm::vec3(14.0f, 1.0f, 10.0f);
    pos = glm::vec3(0.0f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, pos);
    SetShaderMaterial("desk");
    SetTextureUVScale(3.0f, 2.0f);
    SetShaderTexture("desk");
    m_basicMeshes->DrawPlaneMesh();

    //----------------------------------------------------------
    // Notebook base
    //----------------------------------------------------------
    scaleXYZ = glm::vec3(6.2f, 0.20f, 4.2f);
    pos = glm::vec3(-1.0f, 0.22f, 1.5f);
    SetTransformations(scaleXYZ, 0.0f, -15.0f, 0.0f, pos);
    SetShaderMaterial("cover");
    SetShaderTexture("cover");
    m_basicMeshes->DrawBoxMesh();

    //----------------------------------------------------------
    // Notebook pages
    //----------------------------------------------------------
    scaleXYZ = glm::vec3(5.8f, 0.65f, 3.8f);
    pos = glm::vec3(-0.8f, 0.60f, 1.7f);
    SetTransformations(scaleXYZ, 0.0f, -15.0f, 0.0f, pos);
    SetShaderMaterial("pages");
    SetShaderTexture("pages");
    m_basicMeshes->DrawBoxMesh();

    //----------------------------------------------------------
    // Notebook top cover
    //----------------------------------------------------------
    scaleXYZ = glm::vec3(6.2f, 0.20f, 4.2f);
    pos = glm::vec3(-1.0f, 0.95f, 1.5f);
    SetTransformations(scaleXYZ, 0.0f, -15.0f, 0.0f, pos);
    SetShaderMaterial("cover");
    SetShaderTexture("cover");
    m_basicMeshes->DrawBoxMesh();

    //----------------------------------------------------------
    // Metal coffee cup (fixed UV coverage + rounder handle)
    //----------------------------------------------------------
    // CHANGED: moved the cup behind the glasses without touching them
    glm::vec3 cupPos = glm::vec3(4.4f, 1.85f, 0.20f);

    scaleXYZ = glm::vec3(1.1f, 3.0f, 1.1f);
    Xrot = 180.0f;
    Yrot = 0.0f;
    Zrot = 0.0f;
    SetTransformations(scaleXYZ, Xrot, Yrot, Zrot, cupPos);

    SetShaderMaterial("penMetal");
    SetTextureUVScale(1.0f, 2.4f);
    SetShaderTexture("metal");
    m_basicMeshes->DrawTaperedCylinderMesh();

    scaleXYZ = glm::vec3(0.80f, 2.4f, 0.80f);
    pos = cupPos + glm::vec3(0.0f, 0.10f, 0.0f);
    SetTransformations(scaleXYZ, Xrot, Yrot, Zrot, pos);
    SetShaderColor(0.30f, 0.15f, 0.05f, 1.0f);
    m_basicMeshes->DrawTaperedCylinderMesh();

    scaleXYZ = glm::vec3(1.15f, 0.35f, 1.15f);
    pos = cupPos + glm::vec3(0.0f, 1.30f, 0.0f);
    SetTransformations(scaleXYZ, Xrot, Yrot, Zrot, pos);

    SetShaderMaterial("penMetal");
    SetTextureUVScale(1.0f, 2.4f);
    SetShaderTexture("metal");
    m_basicMeshes->DrawTaperedCylinderMesh();

    scaleXYZ = glm::vec3(0.7f, 0.30f, 0.7f);
    pos = cupPos + glm::vec3(0.0f, -1.3f, 0.0f);
    SetTransformations(scaleXYZ, Xrot, Yrot, Zrot, pos);

    SetShaderMaterial("penMetal");
    SetTextureUVScale(1.0f, 2.0f);
    SetShaderTexture("metal");
    m_basicMeshes->DrawTaperedCylinderMesh();

    SetShaderMaterial("penMetal");
    SetTextureUVScale(1.0f, 1.0f);
    SetShaderTexture("metal");

    glm::vec3 handleBase = cupPos + glm::vec3(1.15f, 0.0f, 0.0f);

    glm::vec3 hOff[6] =
    {
        glm::vec3(0.22f,  0.95f,  0.10f),
        glm::vec3(0.35f,  0.55f,  0.22f),
        glm::vec3(0.42f,  0.10f,  0.28f),
        glm::vec3(0.40f, -0.35f,  0.22f),
        glm::vec3(0.30f, -0.75f,  0.10f),
        glm::vec3(0.18f, -1.05f,  0.02f)
    };

    float hRotZ[6] = { 25.0f, 12.0f, 0.0f, -10.0f, -20.0f, -28.0f };

    for (int i = 0; i < 6; i++)
    {
        scaleXYZ = glm::vec3(0.22f, 0.28f, 0.25f);
        pos = handleBase + hOff[i];
        SetTransformations(scaleXYZ, 0.0f, 0.0f, hRotZ[i], pos);
        m_basicMeshes->DrawBoxMesh();
    }

    //----------------------------------------------------------
    // Cheddar pen on notebook (shifted to the side)
    //----------------------------------------------------------
    glm::vec3 penBasePos = glm::vec3(0.2f, 1.05f, 1.3f);
    Xrot = 0.0f;
    Yrot = -35.0f;
    Zrot = 25.0f;

    scaleXYZ = glm::vec3(0.16f, 0.16f, 1.8f);
    pos = penBasePos;
    SetTransformations(scaleXYZ, Xrot, Yrot, Zrot, pos);
    SetShaderMaterial("penCheddar");
    SetTextureUVScale(1.0f, 1.0f);
    SetShaderTexture("penCheddar");
    m_basicMeshes->DrawTaperedCylinderMesh();

    scaleXYZ = glm::vec3(0.18f, 0.18f, 0.25f);
    pos = penBasePos + glm::vec3(0.0f, 0.0f, 0.30f);
    SetTransformations(scaleXYZ, Xrot, Yrot, Zrot, pos);
    SetShaderMaterial("penMetal");
    SetShaderTexture("metal");
    m_basicMeshes->DrawTaperedCylinderMesh();

    scaleXYZ = glm::vec3(0.14f, 0.14f, 0.50f);
    pos = penBasePos + glm::vec3(0.0f, 0.0f, 0.90f);
    SetTransformations(scaleXYZ, Xrot, Yrot, Zrot, pos);
    SetShaderMaterial("penMetal");
    SetShaderTexture("metal");
    m_basicMeshes->DrawTaperedCylinderMesh();

    scaleXYZ = glm::vec3(0.09f, 0.09f, 0.25f);
    pos = penBasePos + glm::vec3(0.0f, 0.0f, 1.25f);
    SetTransformations(scaleXYZ, Xrot, Yrot, Zrot, pos);
    SetShaderColor(0.05f, 0.05f, 0.05f, 1.0f);
    m_basicMeshes->DrawTaperedCylinderMesh();

    //----------------------------------------------------------
    // Pencil holder (textured + more cylinder) + fake hollow inside
    //----------------------------------------------------------
    glm::vec3 pencilCupPos = glm::vec3(-6.4f, 1.90f, 0.2f);

    scaleXYZ = glm::vec3(1.20f, 3.35f, 1.20f);
    Xrot = 180.0f;
    Yrot = 0.0f;
    Zrot = 0.0f;
    SetTransformations(scaleXYZ, Xrot, Yrot, Zrot, pencilCupPos);

    SetShaderMaterial("penMetal");
    SetTextureUVScale(2.0f, 1.0f);
    SetShaderTexture("backdrop");
    m_basicMeshes->DrawTaperedCylinderMesh();

    // ADDED: ring detail around the pencil holder (torus look, but built from small box segments so it compiles clean)
    // I just wanted a small accent that pops, and this reads like a simple ring around the holder.
    {
        SetShaderMaterial("penMetal");
        SetShaderColor(1.0f, 0.85f, 0.15f, 1.0f);  // bright gold so it stands out

        const int segments = 16;
        const float radius = 1.18f;      // sits right around the outside of the cup
        const float ringY = 1.05f;       // height of the ring on the holder
        const float degStep = 360.0f / (float)segments;

        for (int i = 0; i < segments; i++)
        {
            float aDeg = degStep * (float)i;
            float aRad = glm::radians(aDeg);

            float x = std::cos(aRad) * radius;
            float z = std::sin(aRad) * radius;

            // thin little chunk that forms the ring when all segments are placed
            scaleXYZ = glm::vec3(0.18f, 0.08f, 0.40f);
            pos = pencilCupPos + glm::vec3(x, ringY, z);

            // rotate so each segment follows the circle
            SetTransformations(scaleXYZ, 0.0f, -aDeg, 0.0f, pos);
            m_basicMeshes->DrawBoxMesh();
        }
    }

    // Inner dark cylinder to make it look hollow
    {
        glm::vec3 innerPos = pencilCupPos + glm::vec3(0.0f, 0.15f, 0.0f);
        glm::vec3 innerScale = glm::vec3(1.02f, 2.75f, 1.02f);

        SetTransformations(innerScale, Xrot, Yrot, Zrot, innerPos);
        SetShaderColor(0.05f, 0.05f, 0.05f, 1.0f);
        m_basicMeshes->DrawTaperedCylinderMesh();
    }

    float colorR[6] = { 0.95f, 1.0f, 1.0f, 0.2f, 0.2f, 0.6f };
    float colorG[6] = { 0.15f, 0.55f, 0.9f, 0.8f, 0.4f, 0.2f };
    float colorB[6] = { 0.15f, 0.10f, 0.2f, 0.25f, 0.95f, 0.8f };

    glm::vec3 offsets[6] =
    {
        glm::vec3(0.10f, 0.45f,  0.00f),
        glm::vec3(-0.12f, 0.45f,  0.05f),
        glm::vec3(0.00f, 0.45f, -0.12f),
        glm::vec3(0.15f, 0.45f,  0.12f),
        glm::vec3(-0.15f, 0.45f, -0.10f),
        glm::vec3(0.02f, 0.45f,  0.15f)
    };

    float rx[6] = { -3.0f, 4.0f, -5.0f, 6.0f, -4.0f, 3.0f };
    float ry[6] = { 8.0f,-6.0f,  2.0f, 4.0f, -3.0f,-8.0f };
    float rz[6] = { -4.0f, 6.0f, -8.0f, 3.0f,  7.0f,-6.0f };

    const float pencilSink = 0.35f;

    for (int i = 0; i < 6; i++)
    {
        SetShaderMaterial("pencilWood");
        SetShaderColor(colorR[i], colorG[i], colorB[i], 1.0f);

        scaleXYZ = glm::vec3(0.10f, 3.6f, 0.10f);
        pos = pencilCupPos + offsets[i] - glm::vec3(0.0f, pencilSink, 0.0f);
        SetTransformations(scaleXYZ, rx[i], ry[i], rz[i], pos);
        m_basicMeshes->DrawTaperedCylinderMesh();

        SetShaderMaterial("pencilLead");
        SetShaderColor(0.1f, 0.1f, 0.1f, 1.0f);

        scaleXYZ = glm::vec3(0.07f, 0.55f, 0.07f);
        pos = pencilCupPos + offsets[i] + glm::vec3(0.0f, 2.25f, 0.0f) - glm::vec3(0.0f, pencilSink, 0.0f);
        SetTransformations(scaleXYZ, rx[i], ry[i], rz[i], pos);
        m_basicMeshes->DrawTaperedCylinderMesh();
    }

    //----------------------------------------------------------
    // Glasses on the desk (frames PERFECTLY level + clearer lenses)
    //----------------------------------------------------------
    glm::vec3 glassesPos = glm::vec3(4.4f, 0.42f, 2.4f);
    Xrot = 0.0f;
    Yrot = -15.0f;
    Zrot = 0.0f;

    float lensWidth = 1.35f;
    float lensHeight = 0.80f;
    float frameDepthZ = 0.10f;
    float frameThick = 0.08f;

    glm::vec3 leftCenter = glassesPos + glm::vec3(-0.80f, 0.1f, -0.09f);
    glm::vec3 rightCenter = glassesPos + glm::vec3(0.80f, 0.0f, 0.0f);

    SetShaderMaterial("penMetal");
    SetShaderColor(0.03f, 0.03f, 0.03f, 1.0f);

    scaleXYZ = glm::vec3(lensWidth, frameThick, frameDepthZ);

    pos = leftCenter + glm::vec3(0.0f, lensHeight * 0.5f, 0.0f);
    SetTransformations(scaleXYZ, Xrot, Yrot, Zrot, pos);
    m_basicMeshes->DrawBoxMesh();

    pos = leftCenter + glm::vec3(0.0f, -lensHeight * 0.5f, 0.0f);
    SetTransformations(scaleXYZ, Xrot, Yrot, Zrot, pos);
    m_basicMeshes->DrawBoxMesh();

    scaleXYZ = glm::vec3(frameThick, lensHeight, frameDepthZ);

    pos = leftCenter + glm::vec3(-lensWidth * 0.5f, 0.0f, 0.0f);
    SetTransformations(scaleXYZ, Xrot, Yrot, Zrot, pos);
    m_basicMeshes->DrawBoxMesh();

    pos = leftCenter + glm::vec3(lensWidth * 0.5f, 0.0f, 0.0f);
    SetTransformations(scaleXYZ, Xrot, Yrot, Zrot, pos);
    m_basicMeshes->DrawBoxMesh();

    scaleXYZ = glm::vec3(lensWidth, frameThick, frameDepthZ);

    pos = rightCenter + glm::vec3(0.0f, lensHeight * 0.5f, 0.0f);
    SetTransformations(scaleXYZ, Xrot, Yrot, Zrot, pos);
    m_basicMeshes->DrawBoxMesh();

    pos = rightCenter + glm::vec3(0.0f, -lensHeight * 0.5f, 0.0f);
    SetTransformations(scaleXYZ, Xrot, Yrot, Zrot, pos);
    m_basicMeshes->DrawBoxMesh();

    scaleXYZ = glm::vec3(frameThick, lensHeight, frameDepthZ);

    pos = rightCenter + glm::vec3(-lensWidth * 0.5f, 0.0f, 0.0f);
    SetTransformations(scaleXYZ, Xrot, Yrot, Zrot, pos);
    m_basicMeshes->DrawBoxMesh();

    pos = rightCenter + glm::vec3(lensWidth * 0.5f, 0.0f, 0.0f);
    SetTransformations(scaleXYZ, Xrot, Yrot, Zrot, pos);
    m_basicMeshes->DrawBoxMesh();

    scaleXYZ = glm::vec3(0.35f, frameThick, frameDepthZ * 1.1f);
    pos = glassesPos;
    SetTransformations(scaleXYZ, Xrot, Yrot, Zrot, pos);
    m_basicMeshes->DrawBoxMesh();

    scaleXYZ = glm::vec3(0.18f, frameThick, 1.15f);

    pos = leftCenter + glm::vec3(-lensWidth * 0.55f, 0.05f, -0.70f);
    SetTransformations(scaleXYZ, Xrot, Yrot + 15.0f, Zrot, pos);
    m_basicMeshes->DrawBoxMesh();

    pos = rightCenter + glm::vec3(lensWidth * 0.55f, 0.05f, -0.70f);
    SetTransformations(scaleXYZ, Xrot, Yrot - 15.0f, Zrot, pos);
    m_basicMeshes->DrawBoxMesh();

    SetShaderMaterial("glassLens");
    SetShaderColor(0.92f, 0.97f, 1.0f, 0.25f);

    scaleXYZ = glm::vec3(lensWidth * 0.9f, lensHeight * 0.9f, 0.02f);

    pos = leftCenter + glm::vec3(0.0f, 0.0f, 0.01f);
    SetTransformations(scaleXYZ, Xrot, Yrot, Zrot, pos);
    m_basicMeshes->DrawBoxMesh();

    pos = rightCenter + glm::vec3(0.0f, 0.0f, 0.01f);
    SetTransformations(scaleXYZ, Xrot, Yrot, Zrot, pos);
    m_basicMeshes->DrawBoxMesh();
}
